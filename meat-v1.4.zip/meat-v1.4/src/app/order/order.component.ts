import { Component, OnInit } from '@angular/core';

//componente de compra criado atraves do cli na aula 56

@Component({
  selector: 'mt-order',
  templateUrl: './order.component.html'

})
export class OrderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
