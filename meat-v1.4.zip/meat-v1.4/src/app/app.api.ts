export const MEAT_API = 'http://localhost:3000' 
// Api Rest constante para instanciar o db json => assistir aula 43 para fixar conhecimento 
//json-server db.json startar servidor json
//npm install -g json-server instalar servidor json