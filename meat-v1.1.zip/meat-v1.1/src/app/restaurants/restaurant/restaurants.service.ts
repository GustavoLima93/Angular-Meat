import { Injectable } from '@angular/core';
import { Http } from '@angular/http'

import { Observable } from 'rxjs/Observable'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/catch'

import { Restaurant } from "../restaurant/restaurant.model"

// importador Meat api constante criada para instansiar json => assistir aula 43
// importado error handler para tratar erro com catch  => assistir aula 44 

import { MEAT_API } from 'app/app.api'
import { ErrorHandler } from 'app/app.error-handler'


@Injectable()
export class RestaurantsService {


  constructor(private http: Http) { }

// utilizado metodo observable 
//foi pego  uma response e tratado essa response para que virasse um array de restaurantes , essa response veio do Json 

  restaurants(): Observable<Restaurant[]> {
    return this.http.get(`${MEAT_API}/restaurants`).map(Response => Response.json()).catch(ErrorHandler.handleError)

  }
}
