"use strict";
exports.__esModule = true;
exports.apiConfig = {
    secret: 'meat-api-password'
};
