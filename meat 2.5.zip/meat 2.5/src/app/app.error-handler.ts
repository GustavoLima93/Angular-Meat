import { HttpErrorResponse } from "@angular/common/http";
import { Observable } from 'rxjs/Observable'

//Classse para tratar erro utilizando metodo catch => assistir aula 44 novamente 
//foi passado na aula que o tratamento catch pode fazer um tratamento basico direto na camada de serviços e mostrar uam mensagem para usuario caso ocorra algum erro 
//uma boa pratica 

export class ErrorHandler{
    static handleError(error:Response | any){
        let errorMessage: string
if(error instanceof HttpErrorResponse){
    const body = error.error

   errorMessage = `Erro ${error.status} ao acessar a URL ${error.url}-${error.statusText || '' }${body}`  
}else{
    errorMessage = error.ToString()
}

        console.log(errorMessage)
        return Observable.throw(errorMessage)
        
    }
}