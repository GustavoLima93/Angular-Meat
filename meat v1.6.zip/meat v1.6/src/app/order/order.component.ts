import { Component, OnInit } from '@angular/core';
import { RadioOption } from '../shared/radio/radio-option.model';
import { OrderService } from './order.service';
import { CartItem } from '../restaurant-detail/shopping-cart/cart-item.model';

//componente de compra criado atraves do cli na aula 56

@Component({
  selector: 'mt-order',
  templateUrl: './order.component.html'

})
export class OrderComponent implements OnInit {

  delivery: number = 8

  paymentOptions: RadioOption[] = [
    {label: 'Dinheiro', value:'MON'},
    {label: 'Cartao de Debito', value:'DEB'},
    {label: 'Cartao Refeicao', value:'REF'}
  ]

  constructor(private orderService: OrderService) { }

  ngOnInit() {
  }

  cartItems():CartItem[]{
    return this.orderService.cartItems()
  }
 
  itemsValue(): number{
    return this.orderService.itemsValue()
  }

  increaseQty(item:CartItem){
    return this.orderService.increaseQty(item)
  }
  decreaseQty(item:CartItem){
    return this.orderService.decreaseQty(item)
  }
  remove(item:CartItem){
    return this.orderService.remove(item)
  }


}
