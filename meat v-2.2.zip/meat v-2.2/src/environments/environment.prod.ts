export const environment = {
  production: true,
  api:'https://my-json-server.typicode.com/GustavoLima93/json/'
};
